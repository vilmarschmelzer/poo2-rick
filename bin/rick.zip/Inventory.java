import java.util.ArrayList;


public class Inventory {
	private ArrayList<Instrument> listInstru;
	
	public Inventory(){
		this.listInstru=new ArrayList<Instrument>();
	}
	
	public void addinstrumentos(Instrument instrumentos){
		this.listInstru.add(instrumentos);
	}
	
	public void search(Instrument instrumentos){
		
		for (Instrument instrument : this.listInstru) {
			if(instrument.getBuilder().toString().equals(instrumentos.getBuilder().toString())
					&&instrument.getType().toString().equals(instrumentos.getType().toString())){
				System.out.println("Instrumento encontrado...");
				return;
			}
		}
		System.out.println("Instrumento não encontrado...");
	}
}
