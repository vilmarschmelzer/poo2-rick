
public class Builder {
	private int codigo;
	private String nome;
	
	public Builder(int codigo,String nome){
		this.codigo=codigo;
		this.nome=nome;
	}
	
	public String toString(){
		
		return this.codigo+" - "+this.nome;
	}
	
	public void add(Builder builder){
		
		this.nome=builder.nome;
		this.codigo=builder.codigo;
	}
}
