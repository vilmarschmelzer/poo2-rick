
public class Instrument {
	private String serialnumber;
	private double price;
	private boolean eletrico;
	private boolean instrumento_corda;
	private boolean instrumento_percucao;
	private boolean instrumento_tecla;
	private boolean instrumento_sopro;
	private int numero_cordas;
	private int quantidade;
	private Type type;
	private Builder builder;
	private Wood wood;
	
	public Instrument (String serialnumber, double price, boolean eletrico, 
		boolean instrumento_corda, boolean instrumento_percucao, boolean instrumento_tecla, 
		boolean instrumento_sopro, int numero_cordas, int quantidade, Type type, Builder builder, Wood wood){
		this.serialnumber = serialnumber;
		this.price = price;
		this.eletrico = eletrico;
		this.instrumento_corda = instrumento_corda;
		this.instrumento_percucao = instrumento_percucao;
		this.instrumento_tecla = instrumento_tecla;
		this.instrumento_sopro = instrumento_sopro;
		this.numero_cordas = numero_cordas;
		this.quantidade = quantidade;
		this.type = type;
		this.builder = builder;
		this.wood = wood;
	}
	
	public Instrument (Type type, Builder builder, Wood wood){			
		this.type = type;
		this.builder = builder;
		this.wood = wood;
	}
	
	public Builder getBuilder(){
		return this.builder;
	}
	
	public String getModel(){
		return null;
	}
	
	public Type getType(){	
		return this.type;
	}
	
	public void getBackWood(){
		System.out.println(wood.toString());
	}
	
	public void getTopWood(){
		System.out.println(wood.toString());
	}
	
	public void getNumero_cordas(){
		System.out.println(numero_cordas);
	}
}
