
public class Type {
	private int codigo;
	private String nome;
	
	public Type(int codigo,String nome){
		this.codigo=codigo;
		this.nome=nome;
	}
	
	public String toString(){
		
		return this.codigo+" - "+this.nome;
	}
	
	public void add(Type type){
		
		this.nome=type.nome;
		this.codigo=type.codigo;
	}
}
