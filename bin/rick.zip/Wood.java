
public class Wood {
	private int codigo;
	private String nome;
	
	public Wood(int codigo,String nome){
		this.codigo=codigo;
		this.nome=nome;
		
	}
	
	public String toString(){
		
		return this.codigo+" - "+this.nome;
	}
	
	public void add(Wood wood){
		
		this.nome=wood.nome;
		this.codigo=wood.codigo;
	}
}
