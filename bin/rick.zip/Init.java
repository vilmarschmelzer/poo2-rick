import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Init {
	
	private static boolean converteValor(String msg,BufferedReader reader) throws IOException{
		boolean isConverte=false;
		String valor=null;
		while(!isConverte){
			System.out.println(msg);
			valor=reader.readLine();
			if(valor.equalsIgnoreCase("s")||valor.equalsIgnoreCase("n"))
				break;
			else
				System.out.println("Valor invalido");
		}
		
		if(valor.equalsIgnoreCase("s"))
			return true;
		else
			return false;
	}
	
	
	public static void main(String[] args) throws IOException{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		Inventory inventory=new Inventory();
		Instrument instrument=null;
		System.out.println("Sistema Rick");
		
		System.out.println("1- Adicionar Instrumento");
		System.out.println("2- Busca Instrumento");
		System.out.println("3- Sair");
		
		int opcao=0;
		while(true){
			System.out.println("Informe a opcão: ");
			opcao=Integer.parseInt(reader.readLine());
			
			if(opcao==3)
				break;
			
			if(opcao <1 || opcao>3){
				System.out.println("Opção invalida");
				System.out.println("1- Adicionar Instrumento");
				System.out.println("2- Busca Instrumento");
				System.out.println("3- Sair");
			}
			String serialNumber;
			double price;
			boolean eletrico;
			boolean instrumento_corda;
			boolean instrumento_percucao;
			boolean instrumento_tecla;
			boolean instrumento_sopro;
			int numero_cordas;
			int quantidade;
			String type;
			int codigo_type;
			String builder;
			int codigo_builder;
			String wood;
			int codigo_wood;
			
			if(opcao==1){
				
				System.out.println("Informe o numero de serie: ");
				serialNumber= reader.readLine();
				System.out.println("Informe o preço");
				price = Double.parseDouble(reader.readLine());
				
				eletrico = converteValor("Informe se é elétrico (s/n): ",reader);
				instrumento_corda = converteValor("Informe se é de corda (s/n): ",reader);
				instrumento_percucao = converteValor("Informe se é de percução (s/n): ",reader);
				instrumento_tecla = converteValor("Informe se é de teclas (s/n): ",reader);
				instrumento_sopro = converteValor("Informe se é de sopro (s/n): ",reader);
				
				System.out.println("Informe o numero de cordas: ");
				numero_cordas= Integer.parseInt(reader.readLine());
				System.out.println("Informe a quantidade de instrumentos:");
				quantidade= Integer.parseInt(reader.readLine());
				System.out.println("Informe o tipo do instrumento: ");
				type= reader.readLine();
				System.out.println("Informe o codigo do tipo: ");
				codigo_type= Integer.parseInt(reader.readLine());
				System.out.println("Informe o Fabricante: ");
				builder= reader.readLine();
				System.out.println("Informe o codigo do Fabricante: ");
				codigo_builder= Integer.parseInt(reader.readLine());
				System.out.println("Informe a codigo da madeira: ");
				wood= reader.readLine();
				System.out.println("Informe a madeira: ");
				codigo_wood= Integer.parseInt(reader.readLine());
				
				Type typenew=new Type(codigo_type,type);
				Builder buildernew=new Builder(codigo_builder,builder); 
				Wood woodnew=new Wood(codigo_wood,wood);
				
				instrument=new Instrument(serialNumber, 
						price, 
						eletrico, 
						instrumento_corda,
						instrumento_percucao, 
						instrumento_tecla, 
						instrumento_sopro,
						numero_cordas, 
						quantidade, 
						typenew, 
						buildernew, 
						woodnew);
				
				inventory.addinstrumentos(instrument);	
			}
			else if(opcao==2){
				
				System.out.println("Informe o tipo do instrumento: ");
				type= reader.readLine();
				System.out.println("Informe o codigo do tipo: ");
				codigo_type= Integer.parseInt(reader.readLine());
				System.out.println("Informe o Fabricante: ");
				builder= reader.readLine();
				System.out.println("Informe o codigo do Fabricante: ");
				codigo_builder= Integer.parseInt(reader.readLine());
				System.out.println("Informe a codigo da madeira: ");
				wood= reader.readLine();
				System.out.println("Informe a madeira: ");
				codigo_wood= Integer.parseInt(reader.readLine());
				
				Type typenew=new Type(codigo_type,type);
				Builder buildernew=new Builder(codigo_builder,builder); 
				Wood woodnew=new Wood(codigo_wood,wood);
				
				instrument=new Instrument(typenew, buildernew, woodnew);
				
				inventory.search(instrument);
			}
		}
	}
}
